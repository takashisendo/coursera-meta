import { Heading, HStack, Image, Text, VStack } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  return (
      <VStack
          align="start"
          spacing={4}
          bg="white"
          p={6}
          borderRadius="lg"
          boxShadow="lg"
          transition="transform 0.2s"
          _hover={{ transform: "scale(1.05)", cursor: "pointer" }} // Added cursor property
      >
        <Image src={imageSrc} alt={title} borderRadius="lg" />
        <Heading as="h3" size="md" color="gray.700">
          {title}
        </Heading>
        <Text color="gray.500">{description}</Text>
        <HStack spacing={1}>
          <Text fontWeight="bold" color="blue.500">
            Learn more
          </Text>
          <FontAwesomeIcon icon={faArrowRight} />
        </HStack>
      </VStack>
  );
};

export default Card;
